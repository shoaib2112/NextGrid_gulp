#!/bin/bash
kill -9 $(ps aux | grep '/var/node/nextgrid')