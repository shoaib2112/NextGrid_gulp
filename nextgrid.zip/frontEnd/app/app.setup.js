/**
 * Created by MXG0RYP on 5/12/2016.
 */
angular.module('nextGrid',
    [
        'ngAnimate',
        'ui.router',
        'ui.bootstrap',
        'rzModule',
        'ngSanitize',
        'ngCsv',
        'xeditable',
        'ngCookies'
    ]);
