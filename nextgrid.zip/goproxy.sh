#!/bin/bash
# This command allows the interwebs to work for npm
export https_proxy=http://zzzdpdc:Distsuperbowl1@go-proxy.fpl.com:80