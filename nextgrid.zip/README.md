Grid360 is a network visualization tool built with JavaScript, Angular, MongoDB, and Node.

Steps to install: 
	mongodb (admin access needed, add to path)
	node/npm (set proxy for node)

Steps to run:
	anywhere:
		mongod

	in nextGrid:
		node nextGrid.js
		[Now API is at localhost:8080/nextGrid/]

	in browser:
	    http://localhost:8080/nextGrid.html